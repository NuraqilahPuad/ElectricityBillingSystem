
public class storedata_forsearch {
    private String name,address,accnum,current,previous;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAccnum() {
        return accnum;
    }

    public void setAccnum(String accnum) {
        this.accnum = accnum;
    }

    public String getCurrent() {
        return current;
    }

    public void setCurrent(String current) {
        this.current = current;
    }

    public String getPrevious() {
        return previous;
    }

    public void setPrevious(String previous) {
        this.previous = previous;
    }

    public storedata_forsearch() {
    }

    public storedata_forsearch(String name, String address, String accnum, String current, String previous) {
        this.name = name;
        this.address = address;
        this.accnum = accnum;
        this.current = current;
        this.previous = previous;
    }
    
    
    
}
