public class storedata_forlist {
    private String name,accnum,totalconsumed;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccnum() {
        return accnum;
    }

    public void setAccnum(String accnum) {
        this.accnum = accnum;
    }

    public String getTotalconsumed() {
        return totalconsumed;
    }

    public void setTotalconsumed(String totalconsumed) {
        this.totalconsumed = totalconsumed;
    }


    public storedata_forlist() {
    }

    public storedata_forlist(String name,String accnum, String totalconsumed) {
        this.name = name;
        this.accnum = accnum;
        this.totalconsumed= totalconsumed;
      
    }
    
}
