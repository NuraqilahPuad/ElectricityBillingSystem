
import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Server extends javax.swing.JFrame {
    storedata_forsearch pl = new storedata_forsearch(); //Perform Java Class = storedata_forsearch 
    storedata_forlist ml = new storedata_forlist();     //Perform Java Class = storedata_forlist
    //Server
    static ServerSocket ss;
    static Socket s;
    static DataInputStream din;
    static DataOutputStream dout;

    public Server() {

        initComponents();
        jTabbedPane1.setSelectedIndex(7);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        registerBTN = new javax.swing.JButton();
        displayBillBTN = new javax.swing.JButton();
        searchBTN = new javax.swing.JButton();
        listBTN = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        CustomerBill = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        serverTA = new java.awt.TextArea();
        jLabel12 = new javax.swing.JLabel();
        textField6 = new java.awt.TextField();
        jLabel13 = new javax.swing.JLabel();
        textField7 = new java.awt.TextField();
        jLabel14 = new javax.swing.JLabel();
        textField8 = new java.awt.TextField();
        jLabel15 = new javax.swing.JLabel();
        textField9 = new java.awt.TextField();
        jLabel16 = new javax.swing.JLabel();
        textField10 = new java.awt.TextField();
        calculateBTN = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        EditJP = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        textField12 = new java.awt.TextField();
        jButton15 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        textField13 = new java.awt.TextField();
        jLabel20 = new javax.swing.JLabel();
        textField14 = new java.awt.TextField();
        jLabel21 = new javax.swing.JLabel();
        textField15 = new java.awt.TextField();
        jLabel22 = new javax.swing.JLabel();
        textField16 = new java.awt.TextField();
        listJP = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        billJP = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textField1 = new java.awt.TextField();
        jLabel7 = new javax.swing.JLabel();
        textField2 = new java.awt.TextField();
        jLabel8 = new javax.swing.JLabel();
        textField3 = new java.awt.TextField();
        jLabel9 = new javax.swing.JLabel();
        textField4 = new java.awt.TextField();
        jLabel10 = new javax.swing.JLabel();
        textField5 = new java.awt.TextField();
        saveReg = new javax.swing.JButton();
        resetReg = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        receiveTA = new javax.swing.JTextArea();
        jLabel23 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        textField11 = new java.awt.TextField();
        jLabel17 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EBS");
        setResizable(false);
        setSize(new java.awt.Dimension(742, 500));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 204, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setPreferredSize(new java.awt.Dimension(742, 500));

        registerBTN.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        registerBTN.setText("BILLING");
        registerBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        registerBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerBTNActionPerformed(evt);
            }
        });

        displayBillBTN.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        displayBillBTN.setText("DISPLAY BILL");
        displayBillBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        displayBillBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayBillBTNActionPerformed(evt);
            }
        });

        searchBTN.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        searchBTN.setText("SEARCH");
        searchBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBTNActionPerformed(evt);
            }
        });

        listBTN.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        listBTN.setText("LIST");
        listBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        listBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listBTNActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jButton3.setText("NOTIFICATION");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.setPreferredSize(new java.awt.Dimension(117, 32));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 19, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(registerBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(displayBillBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(listBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(104, Short.MAX_VALUE)
                .addComponent(registerBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(displayBillBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(listBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(searchBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 540));

        CustomerBill.setMinimumSize(new java.awt.Dimension(742, 600));
        CustomerBill.setPreferredSize(new java.awt.Dimension(650, 600));
        CustomerBill.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 0));
        jLabel2.setText("CUSTOMER BILL");
        CustomerBill.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 50, -1, 23));

        serverTA.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        serverTA.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        CustomerBill.add(serverTA, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 92, 510, 123));

        jLabel12.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel12.setText("TOTAL CONSUMED (kWh) :");
        CustomerBill.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 234, -1, 32));

        textField6.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        textField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField6ActionPerformed(evt);
            }
        });
        CustomerBill.add(textField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 209, 32));

        jLabel13.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel13.setText("TOTAL BEOFRE TAX :");
        CustomerBill.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 284, -1, 32));

        textField7.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        CustomerBill.add(textField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 280, 209, 32));

        jLabel14.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel14.setText("REBATE (2%):");
        CustomerBill.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 334, 123, 32));

        textField8.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        textField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField8ActionPerformed(evt);
            }
        });
        CustomerBill.add(textField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 370, 209, 32));

        jLabel15.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel15.setText("TAX CHARGE (6%) :");
        CustomerBill.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 384, 164, 32));

        textField9.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        CustomerBill.add(textField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 320, 209, 32));

        jLabel16.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel16.setText("TOTAL AMOUNT (AFTER TAX) :");
        CustomerBill.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 435, -1, 32));

        textField10.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        CustomerBill.add(textField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, 209, 32));

        calculateBTN.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        calculateBTN.setText("CALCULATE");
        calculateBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        calculateBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateBTNActionPerformed(evt);
            }
        });
        CustomerBill.add(calculateBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 470, 110, 32));

        jButton2.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jButton2.setText("SEND");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        CustomerBill.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 470, 81, 32));

        jTabbedPane1.addTab("tab2", CustomerBill);

        EditJP.setMinimumSize(new java.awt.Dimension(650, 600));
        EditJP.setPreferredSize(new java.awt.Dimension(650, 600));

        jLabel4.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 153, 0));
        jLabel4.setText("EDIT CUSTOMER INFORMATION");

        jLabel18.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel18.setText("ACCOUNT NUMBER :");

        textField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField12ActionPerformed(evt);
            }
        });
        textField12.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField12KeyPressed(evt);
            }
        });

        jButton15.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jButton15.setText("SAVE");
        jButton15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel19.setText("NAME :");

        textField13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textField13MouseClicked(evt);
            }
        });
        textField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField13ActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel20.setText("ADDRESS :");

        textField14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textField14MouseClicked(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel21.setText("CURRENT METER (kWh) :");

        textField15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textField15MouseClicked(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel22.setText("PREVIOUS METER (kWh) :");

        textField16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textField16MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout EditJPLayout = new javax.swing.GroupLayout(EditJP);
        EditJP.setLayout(EditJPLayout);
        EditJPLayout.setHorizontalGroup(
            EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EditJPLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EditJPLayout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addContainerGap(378, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EditJPLayout.createSequentialGroup()
                        .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(EditJPLayout.createSequentialGroup()
                                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textField13, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
                                    .addComponent(textField12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(textField14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, EditJPLayout.createSequentialGroup()
                                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel21)
                                    .addComponent(jLabel22))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textField15, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                                    .addComponent(textField16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(94, 94, 94))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EditJPLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(203, 203, 203))
        );
        EditJPLayout.setVerticalGroup(
            EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EditJPLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel4)
                .addGap(36, 36, 36)
                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textField12, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(27, 27, 27)
                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(textField13, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textField14, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textField15, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addGroup(EditJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(textField16, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(162, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab4", EditJP);

        listJP.setMinimumSize(new java.awt.Dimension(650, 600));
        listJP.setPreferredSize(new java.awt.Dimension(742, 500));

        jLabel5.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 153, 0));
        jLabel5.setText("LIST OF ALL CUSTOMER");

        jTable2.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NAME", "ACC NUM", "TOTAL CONSUMED (kWh)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout listJPLayout = new javax.swing.GroupLayout(listJP);
        listJP.setLayout(listJPLayout);
        listJPLayout.setHorizontalGroup(
            listJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listJPLayout.createSequentialGroup()
                .addGroup(listJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(listJPLayout.createSequentialGroup()
                        .addGap(184, 184, 184)
                        .addComponent(jLabel5))
                    .addGroup(listJPLayout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(175, Short.MAX_VALUE))
        );
        listJPLayout.setVerticalGroup(
            listJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(listJPLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel5)
                .addGap(28, 28, 28)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(232, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab5", listJP);

        billJP.setMinimumSize(new java.awt.Dimension(650, 600));
        billJP.setPreferredSize(new java.awt.Dimension(650, 600));

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 51));
        jLabel1.setText("BILLING DETAILS");

        jLabel6.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel6.setText("NAME");

        textField1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        textField1.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        textField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel7.setText("ACCOUNT NUMBER (10 DIGIT)");

        textField2.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        textField2.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        textField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField2ActionPerformed(evt);
            }
        });
        textField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField2KeyPressed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel8.setText("HOME ADDRESS");

        textField3.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel9.setText("CURRENT METER (kWh)");

        textField4.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel10.setText("PREVIOUS METER (kWh)");

        textField5.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        textField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField5ActionPerformed(evt);
            }
        });

        saveReg.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        saveReg.setText("NEXT");
        saveReg.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        saveReg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveRegActionPerformed(evt);
            }
        });

        resetReg.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        resetReg.setText("RESET");
        resetReg.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        resetReg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetRegActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout billJPLayout = new javax.swing.GroupLayout(billJP);
        billJP.setLayout(billJPLayout);
        billJPLayout.setHorizontalGroup(
            billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billJPLayout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(billJPLayout.createSequentialGroup()
                        .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addGap(59, 59, 59)
                        .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(billJPLayout.createSequentialGroup()
                                .addComponent(resetReg, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(saveReg, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(textField4, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                            .addComponent(textField3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(textField2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(textField1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(textField5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(0, 75, Short.MAX_VALUE))
        );
        billJPLayout.setVerticalGroup(
            billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billJPLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel1)
                .addGap(50, 50, 50)
                .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textField1, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(34, 34, 34)
                .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                .addGroup(billJPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetReg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(saveReg, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(71, 71, 71))
        );

        jTabbedPane1.addTab("tab1", billJP);

        receiveTA.setColumns(20);
        receiveTA.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        receiveTA.setRows(5);
        jScrollPane3.setViewportView(receiveTA);

        jLabel23.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 153, 0));
        jLabel23.setText("NOTIFICATION");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 518, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(180, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82))
        );

        jTabbedPane1.addTab("tab7", jPanel7);

        jPanel4.setPreferredSize(new java.awt.Dimension(742, 500));

        jLabel3.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 0));
        jLabel3.setText("FIND CUSTOMER INFORMATION");

        jTable1.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NAME", "ACC NUM", "ADDRESS", "CURRENT METER", "PREVIOUS METER"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        textField11.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        textField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField11ActionPerformed(evt);
            }
        });
        textField11.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField11KeyPressed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jLabel17.setText("ACCOUNT NUMBER :");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(51, 51, 51)
                        .addComponent(textField11, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel3)
                .addGap(49, 49, 49)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField11, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab3", jPanel4);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 765, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 550, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tab8", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setRequestFocusEnabled(false);

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/EBS.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(197, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab6", jPanel3);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(157, -40, 770, 580));

        setBounds(0, 0, 789, 586);
    }// </editor-fold>//GEN-END:initComponents

    private void registerBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerBTNActionPerformed
        jTabbedPane1.setSelectedIndex(3); 
    }//GEN-LAST:event_registerBTNActionPerformed

    private void listBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listBTNActionPerformed
        jTabbedPane1.setSelectedIndex(2); 
    }//GEN-LAST:event_listBTNActionPerformed

    private void displayBillBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayBillBTNActionPerformed

        jTabbedPane1.setSelectedIndex(0); 

    }//GEN-LAST:event_displayBillBTNActionPerformed

    private void searchBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBTNActionPerformed
         jTabbedPane1.setSelectedIndex(5); 
    }//GEN-LAST:event_searchBTNActionPerformed

    private void textField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField5ActionPerformed

    }//GEN-LAST:event_textField5ActionPerformed

    private void saveRegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveRegActionPerformed
        jTabbedPane1.setSelectedIndex(0); //Display Display Bill panel

        //we will apply OOP
        pl.setName(textField1.getText().trim()); //Get the input
        pl.setAccnum(textField2.getText().trim());
        pl.setAddress(textField3.getText().trim());
        pl.setCurrent(textField4.getText().trim());
        pl.setPrevious(textField5.getText().trim());

        //add to jtable1
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel(); //Display Find Customer Information
        model.addRow(new Object[]{pl.getName(), pl.getAccnum(), pl.getAddress(), pl.getCurrent(), pl.getPrevious()}); //Add new row at Find Customer Information
       


    }//GEN-LAST:event_saveRegActionPerformed

    private void textField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField1ActionPerformed

    private void textField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField8ActionPerformed

    private void textField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField2KeyPressed
        String accountnumber = textField2.getText();
        //get length of string
        int length = accountnumber.length();
        char c = evt.getKeyChar();
        //check for number 0 to 9
        if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9') {
            //check for length not more than 10 digit
            if (length < 10) {
                textField2.setEditable(true);
            } else {
                textField2.setEditable(false);
                JOptionPane.showMessageDialog(this, "Cannot more than 10 digit", "message", JOptionPane.ERROR_MESSAGE);
            }

        } else {
            //not allow key back space and delete for edit
            if (evt.getExtendedKeyCode() == KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode() == KeyEvent.VK_DELETE) {
                //than allow to editable
                textField2.setEditable(true);
            } else {
                textField2.setEditable(false);
            }
        }

    }//GEN-LAST:event_textField2KeyPressed

    private void textField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField2ActionPerformed

    private void textField11KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField11KeyPressed
        // Search
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(model);
        jTable1.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(textField11.getText().trim()));


    }//GEN-LAST:event_textField11KeyPressed

    private void textField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField11ActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_textField11ActionPerformed

    private void resetRegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetRegActionPerformed
        // TODO add your handling code here:
        textField1.setText(null);
        textField2.setText(null);
        textField3.setText(null);
        textField4.setText(null);
        textField5.setText(null);
    }//GEN-LAST:event_resetRegActionPerformed

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyPressed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        pl.setName(textField13.getText());
        pl.setAddress(textField14.getText());
        pl.setCurrent(textField15.getText());
        pl.setPrevious(textField15.getText());
        ml.setName(textField13.getText());
        //send input to Search2
        JOptionPane.showMessageDialog(this, "Successfully Edited");
    }//GEN-LAST:event_jButton15ActionPerformed

    private void textField13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textField13MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_textField13MouseClicked

    private void textField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField13ActionPerformed

    private void textField14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textField14MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_textField14MouseClicked

    private void textField15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textField15MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_textField15MouseClicked

    private void textField16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textField16MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_textField16MouseClicked

    private void textField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField12ActionPerformed

    private void textField12KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField12KeyPressed

    }//GEN-LAST:event_textField12KeyPressed

    private void textField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField6ActionPerformed

    private void calculateBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateBTNActionPerformed
        double current = Double.parseDouble(textField4.getText()); //Input from TF4
        double previous = Double.parseDouble(textField5.getText()); //Input from TF5
        double total = current - previous; //Get total consumed
        String totalamount = String.format("%.0f", total);
        double amount;
        double rebate;
        double tax = 0;
        double amountpay;
        textField6.setText(totalamount);

        //we will apply OOP
        /*storedata_forlist ml =new storedata_forlist();*/
        ml.setName(textField1.getText().trim());
        ml.setAccnum(textField2.getText().trim());
        ml.setTotalconsumed(textField6.getText().trim());
        //add to jtable2
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.addRow(new Object[]{ml.getName(), ml.getAccnum(), ml.getTotalconsumed()});

        //2
        if (total <= 200) {
            amount = total * 0.218;
            totalamount = String.format("%.2f", amount);
            textField7.setText(totalamount);
        } else if ((total > 200) && (total <= 300)) {
            amount = (200 * 0.218) + ((total - 200) * 0.334);
            totalamount = String.format("%.2f", amount);
            textField7.setText(totalamount);
        } else if ((total > 300) && (total <= 600)) {
            amount = (200 * 0.218) + (100 * 0.334) + ((total - 300) * 0.516);
            totalamount = String.format("%.2f", amount);
            textField7.setText(totalamount);
        } else if ((total > 600) && (total <= 900)) {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + ((total - 600) * 0.546);
            totalamount = String.format("%.2f", amount);
            textField7.setText(totalamount);
        } else {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + (600 * 0.546) + ((total - 1200) * 0.571);
            totalamount = String.format("%.2f", amount);
            textField7.setText(totalamount);
        }

        //3
        if (total <= 200) {
            amount = total * 0.218;
            if (amount < 0) {
                rebate = 0 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            } else {
                rebate = 0.02 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            }
        } else if ((total > 200) && (total <= 300)) {
            amount = (200 * 0.218) + ((total - 200) * 0.334);
            if (amount < 0) {
                rebate = 0 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            } else {
                rebate = 0.02 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            }
        } else if ((total > 300) && (total <= 600)) {
            amount = (200 * 0.218) + (100 * 0.334) + ((total - 300) * 0.516);
            if (amount < 0) {
                rebate = 0 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            } else {
                rebate = 0.02 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            }
        } else if ((total > 600) && (total <= 900)) {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + ((total - 600) * 0.546);
            if (amount < 0) {
                rebate = 0 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            } else {
                rebate = 0.02 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            }
        } else {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + (600 * 0.546) + ((total - 1200) * 0.571);
            if (amount < 0) {
                rebate = 0 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            } else {
                rebate = 0.02 * amount;
                String totalamountrebate = String.format("%.2f", rebate);
                textField9.setText(totalamountrebate);
            }
        }

        //4
        if (total <= 200) {
            amount = total * 0.218;
            if (amount < 0) {
                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            } else {

                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            }
        } else if ((total > 200) && (total <= 300)) {
            amount = (200 * 0.218) + ((total - 200) * 0.334);
            if (amount < 0) {

                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            } else {

                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            }
        } else if ((total > 300) && (total <= 600)) {
            amount = (200 * 0.218) + (100 * 0.334) + ((total - 300) * 0.516);
            if (amount < 0) {

                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            } else {

                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            }
        } else if ((total > 600) && (total <= 900)) {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + ((total - 600) * 0.546);
            if (amount < 0) {

                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            } else {

                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            }
        } else {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + (600 * 0.546) + ((total - 1200) * 0.571);
            if (amount < 0) {
                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            } else {
                tax = 0.06 * amount;
                String totalamountwtax = String.format("%.2f", tax);
                textField8.setText(totalamountwtax);
            }
        }
        //5

        if (total <= 200) {
            amount = total * 0.218;
            if (amount < 0) {
                rebate = 0 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            } else {
                rebate = 0.02 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            }
        } else if ((total > 200) && (total <= 300)) {
            amount = (200 * 0.218) + ((total - 200) * 0.334);
            if (amount < 0) {
                rebate = 0 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            } else {
                rebate = 0.02 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            }
        } else if ((total > 300) && (total <= 600)) {
            amount = (200 * 0.218) + (100 * 0.334) + ((total - 300) * 0.516);
            if (amount < 0) {
                rebate = 0 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            } else {
                rebate = 0.02 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            }
        } else if ((total > 600) && (total <= 900)) {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + ((total - 600) * 0.546);
            if (amount < 0) {
                rebate = 0 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            } else {
                rebate = 0.02 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            }
        } else {
            amount = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + (600 * 0.546) + ((total - 1200) * 0.571);
            if (amount < 0) {
                rebate = 0 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            } else {
                rebate = 0.02 * amount;
                tax = 0.06 * (amount - rebate);
                amountpay = amount + tax;
                String totalamountpay = String.format("%.2f", amountpay);
                textField10.setText(totalamountpay);
            }
        }
        serverTA.setText("");
        serverTA.append("\tELECTRICITY BILLING SYSTEM\n"
                + "\n==============================================\n"
                + "NAME :\t" + textField1.getText() + "\n\n"
                + "ACCOUNT NUMBER :\t" + textField2.getText() + "\n\n"
                + "HOME ADDRESS :\t" + textField3.getText() + "\n\n"
                + "CURRENT METER READING :\t" + textField4.getText() + "\tkWh\n\n"
                + "PREVIOUS METER READING :\t" + textField5.getText() + "\tkWh\n\n"
                + "TOTAL CONSUMED :\t" + textField6.getText() + "\n\n"
                + "TOTAL BEFORE TAX :\t" + textField7.getText() + "\n\n"
                + "REBATE (2%) :\t" + textField9.getText() + "\n\n"
                + "TAX CHARGE (6%) :\t" + textField8.getText() + "\n\n"
                + "TOTAL AMOUNT (AFTER TAX) :\t" + textField10.getText() + "\n\n"
        );
    }//GEN-LAST:event_calculateBTNActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            String msgout = "";
            msgout = "\tELECTRICITY BILLING SYSTEM\n"
                    + "\n==============================================\n"
                    + "NAME :\t" + textField1.getText() + "\n\n"
                    + "ACCOUNT NUMBER :\t" + textField2.getText() + "\n\n"
                    + "HOME ADDRESS :\t" + textField3.getText() + "\n\n"
                    + "CURRENT METER READING :\t" + textField4.getText() + "\tkWh\n\n"
                    + "PREVIOUS METER READING :\t" + textField5.getText() + "\tkWh\n\n"
                    + "TOTAL CONSUMED :\t" + textField6.getText() + "\n\n"
                    + "TOTAL BEFORE TAX :\t" + textField7.getText() + "\n\n"
                    + "REBATE (2%) :\t" + textField9.getText() + "\n\n"
                    + "TAX CHARGE (6%) :\t" + textField8.getText() + "\n\n"
                    + "TOTAL AMOUNT (AFTER TAX) :\t" + textField10.getText() + "\n\n";
            dout.writeUTF(msgout); //Sending message to client
        } catch (Exception e) {

        }
        JOptionPane.showMessageDialog(this, "Bill Successfully send!");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Server().setVisible(true);
            }
        });
        String msgin = "";

        try {
            ss = new ServerSocket(1201);
            s = ss.accept();

            din = new DataInputStream(s.getInputStream());
            dout = new DataOutputStream(s.getOutputStream());

            while (!msgin.equals("Exit")) {
                msgin = din.readUTF();
                receiveTA.setText(receiveTA.getText().trim() + "\n" + msgin); //display message from client
            }
        } catch (Exception e) {

        }

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CustomerBill;
    private javax.swing.JPanel EditJP;
    private javax.swing.JPanel billJP;
    private javax.swing.JButton calculateBTN;
    private javax.swing.JButton displayBillBTN;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    public javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JButton listBTN;
    private javax.swing.JPanel listJP;
    private static javax.swing.JTextArea receiveTA;
    private javax.swing.JButton registerBTN;
    private javax.swing.JButton resetReg;
    private javax.swing.JButton saveReg;
    private javax.swing.JButton searchBTN;
    public java.awt.TextArea serverTA;
    public static java.awt.TextField textField1;
    public static java.awt.TextField textField10;
    public static java.awt.TextField textField11;
    public static java.awt.TextField textField12;
    public static java.awt.TextField textField13;
    public static java.awt.TextField textField14;
    public static java.awt.TextField textField15;
    public static java.awt.TextField textField16;
    public static java.awt.TextField textField2;
    public static java.awt.TextField textField3;
    public static java.awt.TextField textField4;
    public static java.awt.TextField textField5;
    public static java.awt.TextField textField6;
    public static java.awt.TextField textField7;
    public static java.awt.TextField textField8;
    public static java.awt.TextField textField9;
    // End of variables declaration//GEN-END:variables

}